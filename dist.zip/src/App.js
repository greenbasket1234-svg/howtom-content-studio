import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext.js';
import { AdvertiserProvider } from './context/AdvertiserContext.js';
import { Layout } from './components/Layout.js';
import { HomePage } from './pages/HomePage.js';
import { LoginPage } from './pages/LoginPage.js';
import { StubPage } from './pages/stub/StubPage.js';
function RequireAuth({ children }) {
    const { user } = useAuth();
    if (!user)
        return _jsx(Navigate, { to: "/login", replace: true });
    return (_jsx(AdvertiserProvider, { children: _jsx(Layout, { children: children }) }));
}
function Stub({ title, phase }) {
    return _jsx(RequireAuth, { children: _jsx(StubPage, { title: title, phase: phase }) });
}
export default function App() {
    return (_jsxs(Routes, { children: [_jsx(Route, { path: "/login", element: _jsx(LoginPage, {}) }), _jsx(Route, { path: "/", element: _jsx(RequireAuth, { children: _jsx(HomePage, {}) }) }), _jsx(Route, { path: "/references", element: _jsx(Stub, { title: "\uB808\uD37C\uB7F0\uC2A4 \uD0D0\uC0C9", phase: "PHASE 3" }) }), _jsx(Route, { path: "/references/competitors", element: _jsx(Stub, { title: "\uACBD\uC7C1\uC0AC \uBAA8\uB2C8\uD130\uB9C1", phase: "PHASE 3" }) }), _jsx(Route, { path: "/references/boards", element: _jsx(Stub, { title: "\uB808\uD37C\uB7F0\uC2A4 \uBCF4\uB4DC", phase: "PHASE 3" }) }), _jsx(Route, { path: "/references/settings", element: _jsx(Stub, { title: "\uC218\uC9D1 \uC124\uC815", phase: "PHASE 3" }) }), _jsx(Route, { path: "/production/ad", element: _jsx(Stub, { title: "\uAD11\uACE0 \uC81C\uC791", phase: "PHASE 2" }) }), _jsx(Route, { path: "/production/blog", element: _jsx(Stub, { title: "\uBE14\uB85C\uADF8 \uC81C\uC791", phase: "PHASE 2" }) }), _jsx(Route, { path: "/production/image", element: _jsx(Stub, { title: "\uC774\uBBF8\uC9C0 \uC81C\uC791", phase: "PHASE 2" }) }), _jsx(Route, { path: "/production/video-script", element: _jsx(Stub, { title: "\uC601\uC0C1 \uB300\uBCF8", phase: "PHASE 2" }) }), _jsx(Route, { path: "/production/document", element: _jsx(Stub, { title: "\uBB38\uC11C \uC791\uC131", phase: "PHASE 2" }) }), _jsx(Route, { path: "/library", element: _jsx(Stub, { title: "\uC81C\uC791\uBB3C \uBCF4\uAD00\uD568", phase: "PHASE 2" }) }), _jsx(Route, { path: "/calendar", element: _jsx(Stub, { title: "\uCF58\uD150\uCE20 \uCE98\uB9B0\uB354", phase: "PHASE 2" }) }), _jsx(Route, { path: "/templates", element: _jsx(Stub, { title: "\uD15C\uD50C\uB9BF", phase: "PHASE 2" }) }), _jsx(Route, { path: "/assets/images", element: _jsx(Stub, { title: "\uC774\uBBF8\uC9C0 \uC790\uC0B0", phase: "PHASE 2" }) }), _jsx(Route, { path: "/assets/videos", element: _jsx(Stub, { title: "\uC601\uC0C1 \uC790\uC0B0", phase: "PHASE 2" }) }), _jsx(Route, { path: "/assets/documents", element: _jsx(Stub, { title: "\uBB38\uC11C \uC790\uC0B0", phase: "PHASE 2" }) }), _jsx(Route, { path: "*", element: _jsx(Navigate, { to: "/", replace: true }) })] }));
}

import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.js';
export function LoginPage() {
    const { login } = useAuth();
    const navigate = useNavigate();
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const submit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        try {
            await login(email, password);
            navigate('/');
        }
        catch (err) {
            setError(err instanceof Error ? err.message : String(err));
        }
        setLoading(false);
    };
    return (_jsx("div", { className: "cs-login-wrap", children: _jsxs("form", { className: "cs-login-card", onSubmit: submit, children: [_jsx("h1", { children: "HOWTOM \uCF58\uD150\uCE20 \uC81C\uC791\uC18C" }), _jsx("p", { children: "\uC720\uB2C8\uBC84\uC2A4\uC640 \uAC19\uC740 \uAD00\uB9AC\uC790 \uACC4\uC815\uC73C\uB85C \uB85C\uADF8\uC778\uD569\uB2C8\uB2E4." }), error && _jsx("div", { className: "cs-error", children: error }), _jsxs("label", { children: ["\uC774\uBA54\uC77C", _jsx("input", { type: "email", value: email, onChange: e => setEmail(e.target.value), required: true })] }), _jsxs("label", { children: ["\uBE44\uBC00\uBC88\uD638", _jsx("input", { type: "password", value: password, onChange: e => setPassword(e.target.value), required: true })] }), _jsx("button", { className: "cs-btn cs-btn-primary", style: { width: '100%', marginTop: 8 }, disabled: loading, children: loading ? '로그인 중...' : '로그인' })] }) }));
}

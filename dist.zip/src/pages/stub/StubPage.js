import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
/**
 * PHASE 1에서는 레퍼런스/제작/콘텐츠관리/자산 메뉴가 라우팅만 존재하고,
 * 실제 기능은 아직 없습니다(PHASE 2~3에서 기존 Universe 기능을 이전하거나
 * 새로 구현합니다). 여기서 가짜 데이터로 동작하는 척 만들지 않고,
 * 정직하게 "아직 없다"는 안내만 보여줍니다.
 */
export function StubPage({ title, phase }) {
    return (_jsxs("div", { children: [_jsx("h1", { style: { fontSize: 20, marginBottom: 16 }, children: title }), _jsxs("div", { className: "cs-card cs-stub-card", children: [_jsxs("b", { children: [phase, "\uC5D0\uC11C \uAD6C\uD604\uB420 \uC608\uC815\uC785\uB2C8\uB2E4"] }), "\uC9C0\uAE08\uC740 HOWTOM \uC720\uB2C8\uBC84\uC2A4\uC640\uC758 \uAD11\uACE0\uC8FC \uACF5\uC720\u00B7\uD654\uBA74 \uC774\uB3D9 \uAD6C\uC870(PHASE 1)\uB9CC \uAC80\uC99D\uD558\uB294 \uB2E8\uACC4\uC785\uB2C8\uB2E4."] })] }));
}

import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { AppSwitcher } from './AppSwitcher.js';
import { useAuth } from '../context/AuthContext.js';
import { ALL_ADVERTISERS_ID, useAdvertiserContext } from '../context/AdvertiserContext.js';
const NAV_GROUPS = [
    { label: '', items: [{ to: '/', label: '홈' }] },
    { label: '레퍼런스', items: [
            { to: '/references', label: '레퍼런스 탐색' },
            { to: '/references/competitors', label: '경쟁사 모니터링' },
            { to: '/references/boards', label: '레퍼런스 보드' },
            { to: '/references/settings', label: '수집 설정' },
        ] },
    { label: '제작', items: [
            { to: '/production/ad', label: '광고 제작' },
            { to: '/production/blog', label: '블로그 제작' },
            { to: '/production/image', label: '이미지 제작' },
            { to: '/production/video-script', label: '영상 대본' },
            { to: '/production/document', label: '문서 작성' },
        ] },
    { label: '콘텐츠 관리', items: [
            { to: '/library', label: '제작물 보관함' },
            { to: '/calendar', label: '콘텐츠 캘린더' },
            { to: '/templates', label: '템플릿' },
        ] },
    { label: '자산', items: [
            { to: '/assets/images', label: '이미지' },
            { to: '/assets/videos', label: '영상' },
            { to: '/assets/documents', label: '문서' },
        ] },
];
export function Layout({ children }) {
    const { user, logout } = useAuth();
    const { advertisers, selectedId, setSelectedId, loading } = useAdvertiserContext();
    const [mobileNavOpen, setMobileNavOpen] = useState(false);
    const navigate = useNavigate();
    const nav = (_jsx("nav", { className: "cs-nav", children: NAV_GROUPS.map((group, i) => (_jsxs("div", { children: [group.label && _jsx("div", { className: "cs-nav-group-label", children: group.label }), group.items.map(item => (_jsx(NavLink, { to: item.to, end: true, onClick: () => setMobileNavOpen(false), className: ({ isActive }) => isActive ? 'active' : '', children: item.label }, item.to)))] }, i))) }));
    return (_jsxs("div", { className: "cs-shell", children: [_jsxs("aside", { className: "cs-sidebar", children: [_jsxs("div", { className: "cs-sidebar-logo", children: ["HOWTOM", _jsx("br", {}), "\uCF58\uD150\uCE20 \uC81C\uC791\uC18C"] }), nav] }), mobileNavOpen && (_jsx("div", { className: "cs-mobile-nav-backdrop", onClick: () => setMobileNavOpen(false), children: _jsxs("aside", { className: "cs-mobile-nav", onClick: e => e.stopPropagation(), children: [_jsxs("div", { className: "cs-mobile-nav-head", children: [_jsx("b", { children: "HOWTOM \uCF58\uD150\uCE20 \uC81C\uC791\uC18C" }), _jsx("button", { type: "button", onClick: () => setMobileNavOpen(false), "aria-label": "\uBA54\uB274 \uB2EB\uAE30", children: "\u00D7" })] }), nav] }) })), _jsxs("div", { className: "cs-main", children: [_jsxs("header", { className: "cs-topbar", children: [_jsxs("div", { className: "cs-topbar-left", children: [_jsx("button", { className: "cs-mobile-menu-btn", type: "button", onClick: () => setMobileNavOpen(true), "aria-label": "\uBA54\uB274 \uC5F4\uAE30", children: "\u2630" }), _jsx(AppSwitcher, {})] }), _jsxs("div", { className: "cs-topbar-actions", children: [_jsxs("select", { className: "cs-select", value: selectedId, onChange: e => setSelectedId(e.target.value), disabled: loading, "aria-label": "\uAD11\uACE0\uC8FC \uC120\uD0DD", children: [_jsx("option", { value: ALL_ADVERTISERS_ID, children: loading ? '전체 보기 · 불러오는 중...' : `전체 보기${advertisers.length ? ` (${advertisers.length})` : ''}` }), advertisers.map(a => _jsx("option", { value: a.id, children: a.name }, a.id))] }), _jsx("span", { className: "cs-user-name", children: user?.name }), _jsx("button", { className: "cs-btn", onClick: () => { logout(); navigate('/login'); }, children: "\uB85C\uADF8\uC544\uC6C3" })] })] }), _jsx("main", { className: "cs-content", children: children })] })] }));
}

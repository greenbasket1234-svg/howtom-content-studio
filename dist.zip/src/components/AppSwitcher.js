import { jsx as _jsx, jsxs as _jsxs } from "react/jsx-runtime";
import { useState } from 'react';
// 두 앱은 서로 다른 도메인/서비스로 배포되므로, 환경변수로 서로의 주소를 알려줍니다.
// Vite는 빌드 시점에 VITE_ 접두사가 붙은 값만 클라이언트 코드에 심어줍니다.
const UNIVERSE_URL = "https://universe.howtom.example.com" || 'https://universe.howtom.example.com';
/** 상단에 "HOWTOM ▼" 형태로 표시되는, 유니버스/콘텐츠 제작소 전환 메뉴입니다. */
export function AppSwitcher() {
    const [open, setOpen] = useState(false);
    return (_jsxs("div", { className: "cs-app-switcher", children: [_jsx("button", { className: "cs-btn", onClick: () => setOpen(v => !v), children: "HOWTOM \u25BE" }), open && (_jsxs("div", { className: "cs-app-switcher-menu", onMouseLeave: () => setOpen(false), children: [_jsx("a", { className: "cs-app-switcher-item", href: UNIVERSE_URL, children: "\u25CB \uC720\uB2C8\uBC84\uC2A4" }), _jsx("button", { className: "cs-app-switcher-item active", disabled: true, children: "\u25CF \uCF58\uD150\uCE20 \uC81C\uC791\uC18C" })] }))] }));
}
